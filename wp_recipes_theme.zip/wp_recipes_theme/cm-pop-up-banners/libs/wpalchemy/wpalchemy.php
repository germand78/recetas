<?php
if( !class_exists('WPAlchemy_MetaBox') )
{
    include_once 'class/metabox.php';
}