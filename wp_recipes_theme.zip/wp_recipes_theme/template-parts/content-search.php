<?php
/**
 * Template part for displaying results in search pages.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Tus_Recetas_Favoritas
 */

?>
<!-- <div class="col-sm-12 col-md-12"> -->
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="container search-results">
		<!-- RECIPES START -->
		<div class="row">
			<div class="container-fluid">
		    <div class="row">
				<?php
				//query_posts("paged=$paged");
				if ( have_posts() ) : ?>
					<!-- BANNERS -->
					<!-- <div class="col-md-4 pull-right hidden-sm hidden-xs banner-rail">
						<div><?php dynamic_sidebar ('banner-1'); ?></div>
					</br>
						<div><?php dynamic_sidebar ('banner-2'); ?></div>
					</div> -->
					<?php
					/* Start the Loop */
					while ( have_posts() ) : the_post();
				//if ( 'post' === get_post_type() ) : ?>
					<div class="col-xs-8 col-md-8">
						<div class="result"><div>
								<a href=<?php the_permalink();?>>
									<?php	if (has_post_thumbnail()) {
										the_post_thumbnail('search_image');
									}?>
								</a>
							</div>
							<div class="caption">
								<p class="post-category">	<a href="<?php the_permalink();?>"><?php the_category(', '); ?></a></p>
								<h3 class="post-title">	<a href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
							</div>
						</div>
					</div>
					<?php endwhile;?>
				<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</article><!-- #post-## -->
