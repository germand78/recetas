<?php
/**
 * Template part for displaying posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Tus_Recetas_Favoritas
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="container main-container post-container">
	<div class="row">
		<div class="col-sm-12 col-md-8">
			<div class="container-fluid">
				<div class="entry-content">
					<!-- OLD BANNER-SWEEPS-1  -->

				 <!-- BREADCRUMBS  -->
					<p class="breadcrumbs"><?php if ( function_exists('yoast_breadcrumb') )
					{yoast_breadcrumb('<p id="breadcrumbs" class="breadcrumbs">','</p>');} ?></p>
	            <div class="post-wrapper">
	              <div class="post-header post-wrapper">
		              <div class="title-container">
		                <h3 class="post-title"><?php the_title(); ?></h3>
		              </div>
									<div class="image-container">
									<?php
									if (has_post_thumbnail()) { ?>
										<?php
										//Get the Thumbnail URL
										$src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), array( 720,405 ), false, '' );
										?>
										<img class="img-responsive center-block" src="<?php echo $src[0]; ?>"/>

										<?php echo "<p>".get_post(get_post_thumbnail_id())->post_excerpt;
									  ;}
									  ?></p>
										 <?php
											// }
											?>
									</div>
							</div>
							<?php //echo do_shortcode( '[do_widget id=alobaidirandombannerswidget-7]' ); ?>
				<!-- HIDDEN OVERLAY -->


				<div class="text-wrapper">
				<div id="floating-banner1">
					<div class="floating-banner popup">
						<div>
					    <a href="http://www.tusrecetasfavoritas.com/ofertas/" target="_blank"><img id="ebook-popup" class="img-responsive center-block" src="http://do2762a9n2kwm.cloudfront.net/wp-content/uploads/2016/05/19161851/banner_ebook_320x142.png" ></a>
					    <p>...o puedes</p>
					    <a id="ver-articulo"  class="btn-main prev-link"> ver articulo completo<i class="fa fa-chevron-right"></i></a>
						</div>
					</div>
					<!-- DISPLAY BLURED -->
					<div class="text blured">
						<?php the_content();	?>
					</div>
					<!-- END DISPLAY BLURED -->
				</div>
				<div class="row share-links">
					<div class="col-xs-12 col-md-12">
						<p>
							<strong>Compartir</strong>
							<a href="mailto:?subject=Quiero ver este sitio&amp;body=Revisa este sitio <?php the_permalink(); ?>." title="Compartir por Email">
							<span class="fa-stack fa-lg imail">
								<i class="fa fa-circle-thin fa-stack-2x"></i>
								<i class="fa fa-envelope-o fa-stack-1x"></i>
							</span>
						</a>
							<a target="_blank" href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>">
							<span class="fa-stack fa-lg ifacebook">
								<i class="fa fa-circle-thin fa-stack-2x"></i>
								<i class="fa fa-facebook fa-stack-1x"></i>
							</span></a>
							<a target="_blank" href="https://plus.google.com/share?url=<?php the_permalink(); ?>">
							<span class="fa-stack fa-lg igoogle">
								<i class="fa fa-circle-thin fa-stack-2x"></i>
								<i class="fa fa-google-plus fa-stack-1x"></i>
							</span>
						</a>
							<a target="_blank" href="http://twitter.com/home?status=<?php the_permalink(); ?>">
							<span class="fa-stack fa-lg itwitter">
								<i class="fa fa-circle-thin fa-stack-2x"></i>
								<i class="fa fa-twitter fa-stack-1x"></i>
							</span>
						</a>
						<a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>" class="pin-it-button">
							<span class="fa-stack fa-lg ipinterest">
								<i class="fa fa-circle-thin fa-stack-2x"></i>
								<i class="fa fa-pinterest-p fa-stack-1x"></i>
							</span>
						</a>
						</p>
					</div>
				</div>
			</div>
			</div>
			<!-- </div> -->
		</div>
	</div>
</div>
		<!-- BANNERS -->
		<div class="col-md-4 hidden-sm hidden-xs banner-rail">
			<div><?php dynamic_sidebar ('banner-1'); ?></div>
		<!-- </br>
			<div><?php //dynamic_sidebar ('banner-2'); ?></div> -->
		</div>
	</div>
</div>
</article><!-- #post-## -->
