<?php

 /**
 * Template Name: Contactenos
 *
 * @package  wp_recipes_theme
 * @subpackage wp_recipes_theme
 * @since wp_recipes_theme 1.0.0
 */


?>
<?php get_header(); ?>
<div>

<div class="container-fluid">

</header><!-- .entry-header -->
<div class="entry-meta">
	<?php  ?>
</div><!-- .entry-meta -->
	<div class="single-media col-md-offset-4">
	</br>

		<p><h2>Contáctenos</h2></p>
	</br>

		<?php echo do_shortcode( '[contact-form-7 id="4" title="Contáctenos"]' ); ?>
	</div>
	</div>
</div><!-- END THANK YOU-->
<?php
get_sidebar();
get_footer();

?>
