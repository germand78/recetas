<?php
/**
 * Template part for displaying a message that posts cannot be found.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Tus_Recetas_Favoritas
 */

?>

<section class="no-results not-found">
	<header class="page-header col-md-8 col-md-offset-2">
		<h1 class="page-title"><?php esc_html_e( 'No se encontró alguna información con esas especificaciones', 'wp_lottery_theme' ); ?></h1>
	</header><!-- .page-header -->

	<div class="page-content">
		<div class="col-md-10 col-md-offset-2">

		<?php
		if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>

			<p><?php printf( wp_kses( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'tusrecetasfavoritas' ), array( 'a' => array( 'href' => array() ) ) ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>

		<?php elseif ( is_search() ) : ?>

			<div class="row">
				<div class="col-md-3 col-md-pull-9">	<?php esc_html_e( 'Puede tratar haciendo otra búsqueda o navegar por los hipervínculos que le proporcionamos.', 'tusrecetasfavoritas' ); ?> </div>
				<div class="col-md-9 col-md-push-3">
							<div class="input-group col-md-10 col-md-offset-2">
								<div class="col-md-3"></div>
								<div id="wrap" class="search-full">
		            <form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" id="searchform" autocomplete="on">
		              <input id="search"  type="text" placeholder="Buscar" name="s" id="s">
		                <button id="search_submit" type="submit" class="btn btn-default">
		                  <i class="fa fa-search fa-2x"></i>
		                </button>
		              </form>
		            </div>
		        </div><!--end navbar-colapse-->
		           <div id="wrap" class="search-collapse">
		             <form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" id="searchform" autocomplete="on">
		               <input id="search"  type="text" placeholder="Buscar" name="s" id="s">
		                 <button id="search_submit" type="submit" class="btn btn-default">
		                   <i class="fa fa-search fa-2x"></i>
		                 </button>
		               </form>
		             </div>
							 </div>
						 <!--
			  <div class="col-md-9 col-md-push-3">.col-md-9 .col-md-push-3</div>
			  <div class="col-md-3 col-md-pull-9">.col-md-3 .col-md-pull-9</div> -->
			</div>





				 </div>
				 <div class="col-md-10 col-md-offset-2">
				 <p><?php esc_html_e( 'Puede tratar haciendo otra búsqueda o navegar por los hipervínculos que le proporcionamos.', 'tusrecetasfavoritas' ); ?>
					 <form class="navbar-form" role="search" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" >
						 <div class="input-group">
							 <input type="text" id="searchbox" class="form-control" placeholder="Buscar" name="s" id="s">
							 <div class="input-group-btn">
								 <button class="btn btn-default"  id="searchsubmit"  type="submit"><i class="glyphicon glyphicon-search"></i></button>
							 </div>
						 </div>
					 </form>

				 </p>
			 </div>
					<!-- <form role="search" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" >
						<div class="form-group">
							<input type="text" id="searchbox" class="form-control" placeholder="Buscar" name="s" id="s">
							<div class="input-group-btn">
								<button class="btn btn-default"  id="searchsubmit"  type="submit"><i class="glyphicon glyphicon-search"></i></button>
							</div>
						</div>
					</form> -->


				<!-- </p> -->
			</div>
				<!-- <aside> -->
				<div class="input-group col-md-10 col-md-offset-2">
					<div class="row related-posts ">
							<h1>Mapa del Sitio</h1>
							<ul>
								<?php wp_list_categories( array(
										'orderby'    => 'name',
										'show_count' => true,
										'exclude'    => array( 1 )
								) ); ?>

						</ul>
					</div>
				</div>
			</div>
			<!-- </aside> -->



<div class="row related-posts col-md-12"></div>

			<?php
			//	get_search_form();

		else : ?>

			<p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'tusrecetasfavoritas' ); ?></p>
			<?php
				get_search_form();

		endif; ?>
	</div><!-- .page-content -->
</section><!-- .no-results -->
