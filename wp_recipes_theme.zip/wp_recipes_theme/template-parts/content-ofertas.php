<?php
/**
 * Template Name: Alicorn
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that other 'pages' on your WordPress site will use a different template.
 *
 * @package Tus_Recetas_Favoritas
 * @subpackage Tus_Recetas_Favoritas
 * @since Tus_Recetas_Favoritas 1.0.0
 */

//  if(isset($_GET['InputEmail']))
// {
//  $email = $_GET["InputEmail"];
//  echo $email;
//  } else {
//    echo "nothing";
//  }
global $wp_query;
if (isset($wp_query->query_vars['InputEmail']))
{
echo $wp_query->query_vars['InputEmail'];
}
// $name = get_query_var( 'email' );
// echo $email;
 ?>

 <!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
 <html lang="en">
   <head>
     <meta http-equiv="content-type" content="text/html; charset=utf-8">
     <meta content="width=device-width, initial-scale=1.0" name="viewport">
     <title>Tus Recetas Favoritas</title>
     <?php wp_head(); ?>
     <script type="text/javascript" src=http://alicorn.unicorniomedia.com/loader.js></script>
     <style type="text/css">
       html, body {
         margin: 0 !important;
         width: 100%;
         height: 100%;
       }
     </style>
   </head>
   <body>
   </body>
 </html>
