<?php
/**
 * Template Name: Template Principales Page
 *
 * @package Tus_Recetas_Favoritas
 * @subpackage Tus_Recetas_Favoritas
 * @since Tus_Recetas_Favoritas 1.0.0
 */

?>

<?php
 if ((is_home()) && (is_front_page()) && (is_single())):?>


<!-- if ( is_home() ) &&  ( !is_page_template( 'templates-parts/content-principales.php' ) ):  -->

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
	</header><!-- .entry-header -->

	<aside id="secondary" class="widget-area" role="complementary">
		<!-- START CONTAINER #2 -->
		<div class="container main-container">
		  <!-- RECIPES START -->
		  <div class="row">
		    <div class="col-sm-12 col-md-8">
		      <div class="container-fluid">
		        <div class="row">
		          <h2 class="section-title">Principales Platos </h2>

								<?php
								// Display news hiperlinks
								$args = array( 'posts_per_page' => 10, 'category_name' => 'platos-principales');
								$myposts = get_posts( $args );
								foreach ( $myposts as $post ) : setup_postdata( $post ); ?>

								<div class="col-xs-6 col-md-6">
									<div class="thumbnail">
										<a href=<?php the_permalink();?>>
											<?php if (has_post_thumbnail()) {
											the_post_thumbnail('img-responsive');}?>
										</a>
										<div class="caption">
											<a href=<?php the_permalink();?>><p class="post-category"><?php the_category(', '); ?></p></a>
											<a href=<?php the_permalink();?>><h3 class="post-title"><?php the_title(); ?></h3></a>
										</div>
									</div>
								</div>
							<?php endforeach; ?>
		        </div>
		      </div>
		    <div class="row">
		      <a href=<?php  the_permalink();  ?> class="btn btn-main btn-block">ver mas recetas <span></span></a>
		    </div>
		  </div>

				<!-- BANNERS -->
		  <div class="col-md-4 hidden-sm hidden-xs banner-rail">
		    <div><?php dynamic_sidebar ('banner-1'); ?></div>
				</br>
		    <div><?php dynamic_sidebar ('banner-2'); ?></div>
		  </div>
		</div>
			<!-- BANNNERS END -->
		  <!-- RECIPES END -->
	</div><!-- END CONTAINER #2 -->
</aside>

<div class="nav-links">
	<div class="row">
		<div class="col-xs-12 text-center">
			<ul class="pagination">
				<li>
	<?php
	the_posts_pagination( array(
'mid_size'  => 2,
'prev_text' => __( 'Anterior', 'textdomain' ),
'next_text' => __( 'Siguiente', 'textdomain' ),
) );
		//
		// previous_posts_link ('<-- Anterior ');
		// next_posts_link ('Siguiente -->' );

	?>
</li>
</ul>
</div>
</div>
</div>

	<!-- <div class="entry-content"> -->
		<?php
			// the_content( sprintf(
			// 	/* translators: %s: Name of current post. */
			// 	wp_kses( __( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'tusrecetasfavoritas' ), array( 'span' => array( 'class' => array() ) ) ),
			// 	the_title( '<span class="screen-reader-text">"', '"</span>', false )
			// ) );

			// wp_link_pages( array(
			// 	'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'tusrecetasfavoritas' ),
			// 	'after'  => '</div>',
			// ) );
		?>
	<!-- </div><.entry-content -->

	<footer class="entry-footer">
		<?php //tusrecetasfavoritas_entry_footer(); ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-## -->
<?php endif; ?>
<?php //endif; ?>
