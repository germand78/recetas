<?php

 /**
 * Template Name: Thank you Page
 *
 * @package  wp_recipes_theme
 * @subpackage wp_recipes_theme
 * @since wp_recipes_theme 1.0.0
 */


?>
<?php get_header(); ?>
<div class="container-fluid msg-block">
	<div class="msg center-block">
		<p><span>Felicitaciones!</span>Tu descarga ha sido procesada correctamente
		</p>
		<p class="last"><strong>El ebook con recetas fue enviado a tu correo</strong><br/>Revisalo para completar la descarga</p>

		<a href="http://www.tusrecetasfavoritas.com" class="btn btn-main btn-red btn-block">continua navegando</a>
	</div>
</div><!-- END THANK YOU-->
<?php
get_sidebar();
get_footer();

?>
