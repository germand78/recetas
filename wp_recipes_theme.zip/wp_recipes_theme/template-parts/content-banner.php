<?php
/**
 * Template Name: Template Banner Page
 *
 * @package Tus_Recetas_Favoritas
 * @subpackage Tus_Recetas_Favoritas
 * @since Tus_Recetas_Favoritas 1.0.0
 */

?>
<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Tus_Recetas_Favoritas
 */

 header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">

<?php wp_head(); ?>


<!-- Start Visual Website Optimizer Asynchronous Code -->
<script type='text/javascript'>
var _vwo_code=(function(){
var account_id=180215,
settings_tolerance=2000,
library_tolerance=2500,
use_existing_jquery=false,
// DO NOT EDIT BELOW THIS LINE
f=false,d=document;return{use_existing_jquery:function(){return use_existing_jquery;},library_tolerance:function(){return library_tolerance;},finish:function(){if(!f){f=true;var a=d.getElementById('_vis_opt_path_hides');if(a)a.parentNode.removeChild(a);}},finished:function(){return f;},load:function(a){var b=d.createElement('script');b.src=a;b.type='text/javascript';b.innerText;b.onerror=function(){_vwo_code.finish();};d.getElementsByTagName('head')[0].appendChild(b);},init:function(){settings_timer=setTimeout('_vwo_code.finish()',settings_tolerance);var a=d.createElement('style'),b='body{opacity:0 !important;filter:alpha(opacity=0) !important;background:none !important;}',h=d.getElementsByTagName('head')[0];a.setAttribute('id','_vis_opt_path_hides');a.setAttribute('type','text/css');if(a.styleSheet)a.styleSheet.cssText=b;else a.appendChild(d.createTextNode(b));h.appendChild(a);this.load('//dev.visualwebsiteoptimizer.com/j.php?a='+account_id+'&u='+encodeURIComponent(d.URL)+'&r='+Math.random());return settings_timer;}};}());_vwo_settings_timer=_vwo_code.init();
</script>
<!-- End Visual Website Optimizer Asynchronous Code  -->
</head>

<body <?php body_class(); ?> >

  <!-- Google Tag Manager -->

  <!-- End Google Tag Manager -->

<div id="page" class="site <?php //if ($_COOKIE['suscriptor'] != 1 ) {
?>
<?php //endif; ?>
<?php //if (( !is_home()) &&  (!is_front_page() ) && (!is_archive())) :    ?>
<?php //} ?>"  >
<div id="hidden">
	<header id="masthead" class="site-header" role="banner">
		<div class="site-branding">
			<?php
			if ( is_front_page() && is_home() ) : ?>
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
			<?php else : ?>
				<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
			<?php
			endif;

			$description = get_bloginfo( 'description', 'display' );
			if ( $description || is_customize_preview() ) : ?>
				<p class="site-description"><?php echo $description; /* WPCS: xss ok. */ ?></p>
			<?php
			endif; ?>
		</div><!-- .site-branding -->


    <!-- #site-navigation -->
    <div class="container-fluid main-header">

      <nav class="navbar navbar-default" role="navigation">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle pull-left" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
               <span class="sr-only">Toggle navigation</span><span><i class="fa fa-bars fa-2x"></i></span>
            </button>
            <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img alt="tus recetas favoritas" class="img-responsive" src="http://do2762a9n2kwm.cloudfront.net/wp-content/uploads/2016/04/08154852/tusrecetasfavoritas_logo.png" ></a>
          </div>

        <!--end navbar-header-->
        <div class="collapse navbar-collapse main-nav navbar-right" id="bs-example-navbar-collapse-1">
        <!-- <div class="collapse navbar-collapse menu-primary" id="bs-example-navbar-collapse-1"> -->
          <?php
            wp_nav_menu( array(
           'menu'              => 'primary',
           'theme_location'    => 'primary',
           'depth'             => 2,
           'container'         => 'ul',
           'container_class'   => 'collapse navbar-collapse',
           'container_id'      => 'bs-example-navbar-collapse-1',
           'menu_class'        => 'nav navbar-nav',
           'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
           'walker'            => new wp_bootstrap_navwalker())
            );
         ?>
         <div id="wrap" class="search-full">
           <form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" id="searchform" autocomplete="on">
             <input id="search"  type="text" placeholder="Buscar" name="s" id="s">
               <button id="search_submit" type="submit" class="btn btn-default">
                 <i class="fa fa-search fa-2x"></i>
               </button>
             </form>
           </div>
       </div><!--end navbar-colapse-->
          <div id="wrap" class="search-collapse">
            <form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" id="searchform" autocomplete="on">
              <input id="search"  type="text" placeholder="Buscar" name="s" id="s">
                <button id="search_submit" type="submit" class="btn btn-default">
                  <i class="fa fa-search fa-2x"></i>
                </button>
              </form>
            </div>

      </div><!--end container-->
    </nav>


<?php  if ((in_category( 'guarniciones' )) || (in_category( 'platos-principales' )) || (in_category( 'abc-cocina' )) || (in_category( 'recetas-postres' )) ||
(in_category( 'panes' )) || (in_category( 'recetas-bebidas' )) || (in_category( 'comidas-del-mundo' )) || (in_category( 'recetas-express' )) || (in_category( 'consejos-de-lola' )))   :
 ?>
  <!-- <div class="row top-banner">
    <a href="http://www.gana-premios.co/" target="_blank">
    <img class="img-responsive center-block" src="http://do2762a9n2kwm.cloudfront.net/wp-content/uploads/2016/05/12164703/header-main-img-2-1.png" >
  </a>
    <span></span>
  </div> -->
<?php elseif ((is_page_template ('template-parts/content-thank-you.php'))): ?>

<?php else: ?>
	      <!-- <div class="row top-banner">
          <a href="http://www.gana-premios.co/" target="_blank">
            <img class="img-responsive center-block" src="http://do2762a9n2kwm.cloudfront.net/wp-content/uploads/2016/05/12164703/header-main-img-2-1.png" > -->
            <!-- <img class="img-responsive center-block" src="http://do2762a9n2kwm.cloudfront.net/wp-content/uploads/2016/05/02202300/header-main-img11.png" > -->
        <!-- </a>
	        <span></span>
	      </div> -->
<?php endif; ?>

	    </div>
	    <!-- END CONTAINER #1 -->
	</header><!-- #masthead -->
<!-- COOKIES -->
	<div id="content" class="site-content">
<?php
if ( is_front_page() && is_home() ) :
  get_sidebar();
endif;
?>



<article id="post-3112" class="post-3112 post type-post status-publish format-standard has-post-thumbnail hentry category-abc-cocina tag-como-adobar-carne tag-como-adobar-carne-para-asar
	tag-como-marinar-carne tag-como-marinar-carne-para-asar tag-marinado-de-carne tag-marinar-carne tag-marinar-carne-para-asar">
	<div class="container main-container post-container">
	<div class="row">
		<div class="col-sm-12 col-md-8">
			<div class="container-fluid">
				<div class="entry-content">
					<!-- OLD BANNER-SWEEPS-1  -->

				 <!-- BREADCRUMBS  -->
					<p class="breadcrumbs"><?php if ( function_exists('yoast_breadcrumb') )
					{yoast_breadcrumb('<p id="breadcrumbs" class="breadcrumbs">','</p>');} ?></p>
	            <div class="post-wrapper">
	              <div class="post-header post-wrapper">
		              <div class="title-container">
		                <h3 class="post-title"><?php the_title(); ?></h3>
		              </div>
									<div class="image-container">
									<?php
									if (has_post_thumbnail()) { ?>
										<?php
										//Get the Thumbnail URL
										$src = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), array( 720,405 ), false, '' );
										?>
										<img class="img-responsive center-block" src="<?php echo $src[0]; ?>"/>

										<?php echo "<p>".get_post(get_post_thumbnail_id())->post_excerpt;
									  ;}
									  ?></p>
										 <?php
											// }
											?>
									</div>
							</div>
							<?php //echo do_shortcode( '[do_widget id=alobaidirandombannerswidget-7]' ); ?>
				<!-- HIDDEN OVERLAY -->


				<div  class="text-wrapper">
					<div id="floating-banner2" class="floating-banner popup">
						<div>
					    <a href="http://www.tusrecetasfavoritas.com/ofertas/" target="_blank"><img class="img-responsive center-block" src="http://do2762a9n2kwm.cloudfront.net/wp-content/uploads/2016/05/19161851/banner_ebook_320x142.png" ></a>
					    <p>...o puedes</p>
					    <a id="ver-articulo"  class="btn-main prev-link"> ver articulo completo<i class="fa fa-chevron-right"></i></a>
						</div>
					</div>
					<!-- DISPLAY BLURED -->
					<div class="text blured">
						<?php the_content();	?>
					</div>
					<!-- END DISPLAY BLURED -->

				<div id="social-shared" class="row share-links">
					<div class="col-xs-12 col-md-12">
						<p>
							<strong>Compartir</strong>
							<a href="mailto:?subject=Quiero ver este sitio&amp;body=Revisa este sitio <?php the_permalink(); ?>." title="Compartir por Email">
							<span class="fa-stack fa-lg imail">
								<i class="fa fa-circle-thin fa-stack-2x"></i>
								<i class="fa fa-envelope-o fa-stack-1x"></i>
							</span>
						</a>
							<a target="_blank" href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>">
							<span class="fa-stack fa-lg ifacebook">
								<i class="fa fa-circle-thin fa-stack-2x"></i>
								<i class="fa fa-facebook fa-stack-1x"></i>
							</span></a>
							<a target="_blank" href="https://plus.google.com/share?url=<?php the_permalink(); ?>">
							<span class="fa-stack fa-lg igoogle">
								<i class="fa fa-circle-thin fa-stack-2x"></i>
								<i class="fa fa-google-plus fa-stack-1x"></i>
							</span>
						</a>
							<a target="_blank" href="http://twitter.com/home?status=<?php the_permalink(); ?>">
							<span class="fa-stack fa-lg itwitter">
								<i class="fa fa-circle-thin fa-stack-2x"></i>
								<i class="fa fa-twitter fa-stack-1x"></i>
							</span>
						</a>
						<a href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>" class="pin-it-button">
							<span class="fa-stack fa-lg ipinterest">
								<i class="fa fa-circle-thin fa-stack-2x"></i>
								<i class="fa fa-pinterest-p fa-stack-1x"></i>
							</span>
						</a>
						</p>
					</div>
				</div>
			</div>
			</div>
			<!-- </div> -->
		</div>
	</div>
</div>
		<!-- BANNERS -->
		<div class="col-md-4 hidden-sm hidden-xs banner-rail">
			<div><?php dynamic_sidebar ('banner-1'); ?></div>
		<!-- </br>
			<div><?php //dynamic_sidebar ('banner-2'); ?></div> -->
		</div>
	</div>
</div>
</article><!-- #post-## -->

<?php
get_sidebar();
?>


</div><!-- #content -->
</div><!-- hidden -->

	<footer>
		<nav class="navbar navbar-application">
			<div class="container">
				<div class="disclaimer-wrapper">
					<a href="<?php  esc_url( get_permalink() ); ?>" class="navbar-brand">
						<img alt="Tus Recetas Favoritas logo" src="http://do2762a9n2kwm.cloudfront.net/wp-content/uploads/2016/04/08154842/footer-logo.png"  class="img-responsive">
					</a>
					<p class="disclaimer">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Tusrecetasfavoritas.com</a>
						es un sitio web informativo que provee información sobre las recetas de comidas populares del mundo. Además, proveemos información interesante de consejos sobre la preparación de comidas y tips útiles sobre el uso de algúnos alimentos.

						<br>
						<br>
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Tusrecetasfavoritas.com</a>
						 es de propiedad privada y no se encuentra asociado a ninguna agencia gubernamental. .
						<br>
						<br>Si desea comunicarse con nosotros <a href="<?php echo esc_url( home_url( '/' ) ); ?>contactenos/">Contáctenos</a>

						<hr />


					</p>
				</div>
			</div>
			<div class="footer-links-wrapper">
				<div class="container">
					<ul class="nav navbar-nav text-center">
						<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>politicas-de-privacidad">Políticas De Privacidad</a></li>
						<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>terminos-y-condiciones">Términos Y Condiciones</a></li>
						<li class="copyright">Copyright &copy; 2016 Tusrecetasfavoritas.com</li>
					</ul>
				</div>
			</div>
		</nav>
	</footer>
	<script type='text/javascript' src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>

	<script>
		$(document).ready(function() {
			$("#ver-articulo").click(function(){
				$(".text-wrapper .text").removeClass("blured");
				$(".text-wrapper .floating-banner.popup").remove();
			});
		});
	</script>


	<script>
	//CODIGO SCROLL BANNER

 // CON 400 FUNCIONA PARA PANTALLA NORMALES Y 200 PARA MOBILE
 $().ready(function() {
   var anchov=$(window).width();
	 console.log (anchov);
	 if (anchov >= 460 ){
		 var marginvar = 400;
	 } else {
		 var marginvar = 200;
	 }

	 var $scrollingDiv = $("#floating-banner2");
	 var position = $(".text-wrapper").position().top; // div before you want to stop
	 var height = $("#floating-banner2").height(); //scrolling div can have dynamic height
	 if (anchov >= 460 ){
	 	var positionBottom =  $(".text-wrapper").height() - ($(".social-shared").height());
	} else {
		var positionBottom =  $(".text-wrapper").height() - $(".social-shared").height() - 150;
	}
	 $("#floating-banner2 popup").css({"margin-top" : "1px" });
	 $(window).scroll(function(){
	 if($(window).scrollTop() > position && $(window).scrollTop() < positionBottom){    //100 is value after it start moving when scrooling
		 $scrollingDiv
		 .stop()
		 .animate({"marginTop": ($(window).scrollTop() - marginvar) + "px"}, "slow" );

		 }
	 });
	 });


	</script>

<?php wp_footer(); ?>
<script>
// SAME HEIGHT FROM TABLES
 function sameHeight() {
   var maxHeight = 0;
   var sameHeightElements = $('.thumbnail');
   sameHeightElements.each(function(){
     $el = $(this);
     $el.css('min-height', 0);
     maxHeight = Math.max(maxHeight, $el.outerHeight());
   });
   sameHeightElements.css('min-height', maxHeight + 'px');
 };

// Import Fonts
   WebFontConfig = {
     google: { families: [ 'Fjalla+One::latin' ] }
   };
   (function() {
     var wf = document.createElement('script');
     wf.src = 'https://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
     wf.type = 'text/javascript';
     wf.async = 'true';
     var s = document.getElementsByTagName('script')[0];
     s.parentNode.insertBefore(wf, s);
   })();
// End Import Font

 /*	This function sets the cookie	*/
 function iLoveCookies(){
		days=30; // number of days to keep the cookie
		myDate = new Date();
		myDate.setTime(myDate.getTime()+(days*24*60*60*1000));
		//document.cookie="suscriptor=1; expires=Thu, 18 Dec 2017 12:00:00 UTC; path=/";
		document.cookie="suscriptor=1; path=/; expires=" + myDate.toGMTString();

 }
 /*	end of cookie function	*/

 $(document).on('ready', function(){
     $(window).resize(sameHeight);
   sameHeight();
 });
</script>

</body>
</html>
