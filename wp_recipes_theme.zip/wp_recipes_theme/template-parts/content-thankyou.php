<?php

 /**
 * Template Name: Lottery Contactenos Page
 *
 * @package  wp_lottery_theme
 * @subpackage wp_lottery_theme
 * @since wp_lottery_theme 1.0.0
 */


?>
<?php get_header(); ?>
			<header class="entry-header">



				<div class="entry-meta">
					<?php //wp_lottery_theme_posted_on(); ?>
				</div><!-- .entry-meta -->
			</header><!-- .entry-header -->
				<div class="col-md-offset-4">
					<?php  get_template_part( 'template-parts/content', 'page' ); ?>
				</div>
	</div>
<?php
get_sidebar();
get_footer();

?>
